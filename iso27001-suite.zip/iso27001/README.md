# ISO 27001 Suite

Herramientas web para la implementación, gestión y auditoría de un Sistema de Gestión de Seguridad de la Información (SGSI) conforme a **ISO/IEC 27001:2022**.

Sin dependencias. Sin servidor. Solo HTML, CSS y JavaScript puro.

---

## Módulos

| Módulo | Descripción |
|--------|-------------|
| **Dashboard** | Panel principal con métricas consolidadas de todos los módulos |
| **Gap Analysis** | Evaluación de los 93 controles del Anexo A (Inexistente / Parcial / Completo / N/A) |
| **Gestión de riesgos** | Registro de riesgos con matriz probabilidad × impacto y plan de tratamiento |
| **Auditoría interna** | Checklist por cláusulas 4–10, registro de no conformidades y observaciones |
| **Gestión de evidencias** | Inventario de documentos obligatorios con estados y exportación CSV |

---

## Uso

1. Clona o descarga el repositorio
2. Abre `index.html` en tu navegador
3. No requiere instalación ni servidor

```bash
git clone https://github.com/TU_USUARIO/iso27001-suite.git
cd iso27001-suite
open index.html
```

> Los datos se guardan en `localStorage` del navegador. Para persistencia a largo plazo, usa la función **Exportar CSV** disponible en cada módulo.

---

## Estructura del proyecto

```
iso27001/
├── index.html                  # Dashboard principal
├── css/
│   └── styles.css              # Estilos globales
└── modules/
    ├── gap-analysis.html       # Módulo 1 — Análisis de brechas
    ├── risk-management.html    # Módulo 2 — Gestión de riesgos
    ├── audit.html              # Módulo 3 — Auditoría interna
    └── evidence.html           # Módulo 4 — Gestión de evidencias
```

---

## Funcionalidades destacadas

- **Gap Analysis**: Evaluación interactiva de los 93 controles del Anexo A por dominio (A.5–A.8), con barra de progreso y exportación CSV
- **Riesgos**: Matriz visual 5×5 de probabilidad × impacto, clasificación automática (Bajo / Medio / Alto / Crítico), exportación CSV
- **Auditoría**: Checklist por cláusula (4 a 10) con marcado de Conforme / No conformidad / Observación / N/A. Los hallazgos se consolidan automáticamente
- **Evidencias**: Plantilla precargada con los 18 documentos obligatorios de ISO 27001, gestión de estados (Pendiente → En revisión → Aprobado)

---

## Normas de referencia

- ISO/IEC 27001:2022 — Requisitos del SGSI
- ISO/IEC 27002:2022 — Controles de seguridad (Anexo A)
- ISO/IEC 27005 — Gestión de riesgos de SI

---

## Licencia

MIT — libre para uso personal y comercial.
